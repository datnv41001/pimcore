<?php declare(strict_types=1);

namespace GraphQL\Type\Definition;

/*
export type GraphQLCompositeType =
GraphQLObjectType |
GraphQLInterfaceType |
GraphQLUnionType;
*/

interface CompositeType {}
