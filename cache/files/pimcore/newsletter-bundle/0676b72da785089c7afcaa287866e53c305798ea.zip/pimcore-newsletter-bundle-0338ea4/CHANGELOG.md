#### v1.2.0
- Bumped minimum requirement of `doctrine/dbal` to `3.6`
- Deprecated constant `Connection::PARAM_STR_ARRAY` usages replaced with `ArrayParameterType::STRING`
- 
#### v1.1.0
- Bumped minimum requirement of `admin-ui-classic-bundle` to `1.1`
