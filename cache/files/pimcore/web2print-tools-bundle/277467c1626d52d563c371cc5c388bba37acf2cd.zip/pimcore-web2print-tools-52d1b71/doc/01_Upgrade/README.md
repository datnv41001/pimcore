# Update Notes

## Update to Version 5.2
### General
- Dropped support of Pimcore 10, bumped minimum requirement of `pimcore/pimcore` to `^11.2`. Replaced all `$request->get()` with their explicit input source.