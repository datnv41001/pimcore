#### v4.1.0
 - Dropped support `pimcore/pimcore` `10.6`, bumped minimum requirement to `11.2`
