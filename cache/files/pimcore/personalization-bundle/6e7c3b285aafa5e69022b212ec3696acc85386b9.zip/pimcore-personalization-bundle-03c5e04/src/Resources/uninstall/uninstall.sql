DROP TABLE IF EXISTS `targeting_rules`;
DROP TABLE IF EXISTS `targeting_storage`;
DROP TABLE IF EXISTS `targeting_target_groups`;