import "bootstrap/dist/css/bootstrap.css";
window.bootstrap = require('bootstrap/dist/js/bootstrap.bundle.js');
