import Chart from 'chart.js/auto'

// Ensure the Chart class is loaded in the global context
window.Chart = Chart
