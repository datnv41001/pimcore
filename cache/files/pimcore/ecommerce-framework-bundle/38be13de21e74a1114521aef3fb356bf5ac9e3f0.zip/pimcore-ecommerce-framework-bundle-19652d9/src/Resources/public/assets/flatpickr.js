import "flatpickr/dist/flatpickr.min.css";
import * as flatpickr from "flatpickr";
