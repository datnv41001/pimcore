# Upgrade Notes

#### v1.2.1
- Removed the package "rybakit/twig-deferred-extension". If you extend the twig layout from the E-Commerce Framework, 
  please check if custom CSS/JS code added by `pimcore_head_script` and `pimcore_head_link` is still working. 
