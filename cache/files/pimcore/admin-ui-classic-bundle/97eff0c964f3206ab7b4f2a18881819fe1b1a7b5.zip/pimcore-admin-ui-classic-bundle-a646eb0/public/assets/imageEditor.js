import "../js/lib/minipaint/dist/bundle";
