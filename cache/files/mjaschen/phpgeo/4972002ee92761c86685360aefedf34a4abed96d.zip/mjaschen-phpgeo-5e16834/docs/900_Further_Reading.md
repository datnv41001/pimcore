# Further Reading / Sources

- [Movable Type Scripts](https://www.movable-type.co.uk/scripts/latlong.html)
- [Aviation Formulary V1.24 by Ed Williams](https://www.edwilliams.org/ftp/avsig/avform.txt)
- [Perpendicular Distance Calculator](https://biodiversityinformatics.amnh.org/open_source/pdc/index.html) ([Github](https://github.com/persts/GeographicDistanceTools))
- [W. Randolph Franklin, PNPOLY - Point Inclusion in Polygon Test](https://wrfranklin.org/Research/Short_Notes/pnpoly.html)
