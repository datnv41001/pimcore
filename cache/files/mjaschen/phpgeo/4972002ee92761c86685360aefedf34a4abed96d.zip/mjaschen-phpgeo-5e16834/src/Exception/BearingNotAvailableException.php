<?php

declare(strict_types=1);

namespace Location\Exception;

class BearingNotAvailableException extends \RuntimeException
{
}
