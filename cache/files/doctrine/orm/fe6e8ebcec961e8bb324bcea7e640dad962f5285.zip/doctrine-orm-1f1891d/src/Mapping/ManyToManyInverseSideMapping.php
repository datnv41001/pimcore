<?php

declare(strict_types=1);

namespace Doctrine\ORM\Mapping;

final class ManyToManyInverseSideMapping extends ToManyInverseSideMapping implements ManyToManyAssociationMapping
{
}
