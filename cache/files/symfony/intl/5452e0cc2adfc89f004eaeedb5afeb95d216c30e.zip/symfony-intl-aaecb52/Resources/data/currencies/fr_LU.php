<?php

return [
    'Names' => [
        'FRF' => [
            'FRF',
            'franc français',
        ],
        'LUF' => [
            'F',
            'franc luxembourgeois',
        ],
    ],
];
