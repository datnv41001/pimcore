<?php

return [
    'Names' => [
        'FRF' => [
            'F',
            'franc francès',
        ],
    ],
];
