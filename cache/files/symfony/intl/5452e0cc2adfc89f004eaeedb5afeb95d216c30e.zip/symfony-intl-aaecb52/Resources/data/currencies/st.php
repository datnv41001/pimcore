<?php

return [
    'Names' => [
        'ZAR' => [
            'R',
            'ZAR',
        ],
    ],
];
