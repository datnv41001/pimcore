<?php

return [
    'Names' => [
        'NAD' => [
            '$',
            'Namibiese dollar',
        ],
    ],
];
