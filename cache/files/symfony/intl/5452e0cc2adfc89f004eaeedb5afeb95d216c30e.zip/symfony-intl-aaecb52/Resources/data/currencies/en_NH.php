<?php

return [
    'Names' => [
        'VUV' => [
            'VT',
            'Vanuatu Vatu',
        ],
    ],
];
