<?php

return [
    'Names' => [
        'GHS' => [
            'GH₵',
            'Ghanaian Cedi',
        ],
    ],
];
