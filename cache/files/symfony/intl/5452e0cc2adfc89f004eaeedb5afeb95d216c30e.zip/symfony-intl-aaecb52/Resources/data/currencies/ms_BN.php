<?php

return [
    'Names' => [
        'BND' => [
            '$',
            'Dolar Brunei',
        ],
    ],
];
