<?php

declare(strict_types=1);

namespace Gotenberg;

interface Index
{
    public function create(): string;
}
