<?php

declare(strict_types=1);

namespace MaxMind\Exception;

// phpcs:disable
class IpAddressNotFoundException extends InvalidRequestException {}
